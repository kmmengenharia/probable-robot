#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Page Builder CK Scanner — BlackHat Team edition.

Detect Joomla sites running Page Builder CK (com_pagebuilderck) by probing:
    /components/com_pagebuilderck/assets/pagebuilderck.js

Telegram: https://t.me/mrzblackhat
Credits: Peyman Siyahi | MR.PERSIA

AUTHORIZED USE ONLY — scan systems you own or have explicit permission to test.
"""

from __future__ import annotations

import argparse
import os
import signal
import sys
import threading
import time
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urlparse

try:
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    from requests.packages.urllib3.util.retry import Retry

    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except ImportError:
    sys.exit("[-] missing dependency: pip install requests")

# ── BlackHat Team ─────────────────────────────────────────────────────────────
TEAM_NAME = "BlackHat Team"
TELEGRAM = "https://t.me/mrzblackhat"
TELEGRAM_HANDLE = "@mrzblackhat"
CREDITS = ("Peyman Siyahi", "MR.PERSIA")
# ─────────────────────────────────────────────────────────────────────────────

PROBE_PATH = "/components/com_pagebuilderck/assets/pagebuilderck.js"
DEFAULT_OUTPUT = "pagebuilderck_found.txt"
DEFAULT_THREADS = 64
DEFAULT_TIMEOUT = 12
UA = (
    f"BlackHatTeam/{TELEGRAM_HANDLE} "
    "(Mozilla/5.0; compatible; PageBuilderCK-Scanner/1.0)"
)

SIGNATURES = (
    b"pagebuilderck",
    b"com_pagebuilderck",
    b"Pagebuilderck",
    b"PAGEBUILDERCK",
)

HTML_MARKERS = (b"<!doctype", b"<html", b"<head", b"404 not found", b"page not found")


def _banner() -> str:
    credits = " & ".join(CREDITS)
    return f"""
╔══════════════════════════════════════════════════════════════╗
║                      {TEAM_NAME:^30}                      ║
╠══════════════════════════════════════════════════════════════╣
║  Author  : {TELEGRAM_HANDLE:<47} ║
║  Channel : {TELEGRAM:<47} ║
║  Credits : {credits:<47} ║
╚══════════════════════════════════════════════════════════════╝
"""


@dataclass
class ScanStats:
    total: int = 0
    checked: int = 0
    found: int = 0
    errors: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def bump(self, *, checked: int = 0, found: int = 0, errors: int = 0) -> None:
        with self.lock:
            self.checked += checked
            self.found += found
            self.errors += errors


class LiveResultWriter:
    """Thread-safe, immediate append with flush + fsync."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._seen: set[str] = set()
        path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = path.open("a", encoding="utf-8")

    def add(self, url: str) -> bool:
        with self._lock:
            if url in self._seen:
                return False
            self._seen.add(url)
            self._fh.write(url + "\n")
            self._fh.flush()
            os.fsync(self._fh.fileno())
            return True

    def close(self) -> None:
        with self._lock:
            self._fh.close()


def normalize_url(raw: str) -> Optional[str]:
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    if "://" not in raw:
        raw = "https://" + raw
    parsed = urlparse(raw)
    if not parsed.netloc:
        return None
    scheme = parsed.scheme.lower()
    if scheme not in ("http", "https"):
        return None
    return f"{scheme}://{parsed.netloc}"


def load_targets(path: Path) -> list[str]:
    seen: set[str] = set()
    targets: list[str] = []
    with path.open(encoding="utf-8", errors="replace") as fh:
        for line in fh:
            url = normalize_url(line)
            if url and url not in seen:
                seen.add(url)
                targets.append(url)
    return targets


def looks_like_html(body: bytes) -> bool:
    head = body[:512].lower()
    return any(marker in head for marker in HTML_MARKERS)


def is_pagebuilderck_asset(status: int, body: bytes) -> bool:
    if status != 200 or len(body) < 64:
        return False
    if looks_like_html(body):
        return False
    lower = body.lower()
    return any(sig.lower() in lower for sig in SIGNATURES)


def build_session(timeout: int) -> requests.Session:
    sess = requests.Session()
    sess.headers["User-Agent"] = UA
    sess.headers["Accept"] = "application/javascript, text/javascript, */*;q=0.8"
    sess.headers["X-Authored-By"] = f"{TEAM_NAME};{TELEGRAM}"
    retry = Retry(
        total=1,
        connect=1,
        read=1,
        backoff_factor=0.2,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "HEAD"]),
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=32, pool_maxsize=32)
    sess.mount("http://", adapter)
    sess.mount("https://", adapter)
    sess.verify = False
    sess.timeout = timeout  # type: ignore[attr-defined]
    return sess


_thread_local = threading.local()


def get_thread_session(timeout: int) -> requests.Session:
    sess = getattr(_thread_local, "session", None)
    if sess is None:
        sess = build_session(timeout)
        _thread_local.session = sess
    return sess


def probe_target(base: str, timeout: int) -> tuple[str, bool, str]:
    """
    Returns (normalized_url, is_hit, detail).
    Tries HTTPS first; on connection errors, falls back to HTTP.
    """
    sess = get_thread_session(timeout)

    parsed = urlparse(base)
    schemes = ["https", "http"] if parsed.scheme == "https" else ["http", "https"]

    last_err = ""
    for scheme in schemes:
        url = f"{scheme}://{parsed.netloc}{PROBE_PATH}"
        try:
            r = sess.get(url, timeout=timeout, allow_redirects=True)
            if is_pagebuilderck_asset(r.status_code, r.content):
                return normalize_url(url.split(PROBE_PATH)[0]) or base, True, f"HTTP {r.status_code}"
            last_err = f"HTTP {r.status_code} ({len(r.content)} bytes)"
        except requests.RequestException as exc:
            last_err = str(exc)
            continue

    return base, False, last_err or "no response"


def print_progress(stats: ScanStats, *, final: bool = False) -> None:
    with stats.lock:
        checked, total, found, errors = stats.checked, stats.total, stats.found, stats.errors
    pct = (checked / total * 100) if total else 100.0
    line = f"\r[*] progress {checked}/{total} ({pct:5.1f}%) | found: {found} | errors: {errors}"
    if final:
        print(line)
    else:
        sys.stdout.write(line)
        sys.stdout.flush()


def run_scan(
    targets: Iterable[str],
    *,
    threads: int,
    timeout: int,
    output: Path,
    verbose: bool,
) -> ScanStats:
    target_list = list(targets)
    stats = ScanStats(total=len(target_list))
    writer = LiveResultWriter(output)
    stop_event = threading.Event()

    def _handle_sigint(_signum, _frame) -> None:
        stop_event.set()
        print("\n[!] interrupt received — finishing in-flight probes, then exiting…")

    signal.signal(signal.SIGINT, _handle_sigint)

    print(f"[*] targets  : {stats.total}")
    print(f"[*] threads  : {threads}")
    print(f"[*] timeout  : {timeout}s")
    print(f"[*] probe    : {PROBE_PATH}")
    print(f"[*] output   : {output.resolve()} (live append)")
    print("-" * 60)

    def worker(url: str) -> None:
        if stop_event.is_set():
            return
        hit_url, hit, detail = probe_target(url, timeout)
        if hit:
            if writer.add(hit_url):
                stats.bump(found=1)
                print(f"\n[+] FOUND  : {hit_url}  ({detail})")
        else:
            if verbose:
                print(f"\n[-] miss   : {url}  ({detail})")
            if "error" in detail.lower() or "timeout" in detail.lower():
                stats.bump(errors=1)
        stats.bump(checked=1)
        print_progress(stats)

    with ThreadPoolExecutor(max_workers=threads, thread_name_prefix="pbck") as pool:
        pending: set[Future] = set()
        for url in target_list:
            if stop_event.is_set():
                break
            pending.add(pool.submit(worker, url))
            if len(pending) >= threads * 4:
                done, pending = wait(pending, return_when=FIRST_COMPLETED)
                for _ in done:
                    pass

        while pending:
            done, pending = wait(pending, return_when=FIRST_COMPLETED)
            for _ in done:
                pass

    writer.close()
    print_progress(stats, final=True)
    return stats


def prompt_input_file() -> Path:
    while True:
        raw = input("[?] path to targets .txt file: ").strip().strip("'\"")
        if not raw:
            print("    enter a file path.")
            continue
        path = Path(raw).expanduser()
        if path.is_file():
            return path
        print(f"    file not found: {path}")


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description=(
            f"Page Builder CK scanner — {TEAM_NAME} ({TELEGRAM}) — authorized use only"
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("-i", "--input", type=Path, help="targets file (one URL/host per line)")
    ap.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path(DEFAULT_OUTPUT),
        help="output file for hits (appended immediately)",
    )
    ap.add_argument("-t", "--threads", type=int, default=DEFAULT_THREADS, help="worker thread count")
    ap.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="HTTP timeout per request (seconds)")
    ap.add_argument("-v", "--verbose", action="store_true", help="print misses and errors")
    return ap.parse_args()


def main() -> None:
    print(_banner())
    args = parse_args()

    if args.threads < 1:
        sys.exit("[-] --threads must be >= 1")

    input_path = args.input or prompt_input_file()
    targets = load_targets(input_path)
    if not targets:
        sys.exit(f"[-] no valid targets in {input_path}")

    t0 = time.monotonic()
    stats = run_scan(
        targets,
        threads=args.threads,
        timeout=args.timeout,
        output=args.output,
        verbose=args.verbose,
    )
    elapsed = time.monotonic() - t0

    print("-" * 60)
    print(f"[*] done in {elapsed:.1f}s — {stats.found} hit(s) -> {args.output.resolve()}")
    if stats.found:
        sys.exit(0)
    sys.exit(1)


if __name__ == "__main__":
    main()
