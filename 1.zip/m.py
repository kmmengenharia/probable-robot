import os
import re
import json
import time
import subprocess
import argparse
import psutil
from colorama import Fore, Style, init

init(autoreset=True)

SESSION_PREFIX = "instancia_automacao_"
ARQUIVO_PROGRESSO = "progresso.json"
ARQUIVO_STATUS = "status.json"


def limpar_tela():
    os.system('cls' if os.name == 'nt' else 'clear')


def carregar_progresso():
    """Carrega o histórico de arquivos já concluídos."""
    if os.path.exists(ARQUIVO_PROGRESSO):
        try:
            with open(ARQUIVO_PROGRESSO, 'r', encoding='utf-8') as f:
                return set(json.load(f))
        except Exception:
            return set()
    return set()


def salvar_progresso(processados):
    """Salva pontualmente o histórico de arquivos concluídos."""
    try:
        with open(ARQUIVO_PROGRESSO, 'w', encoding='utf-8') as f:
            json.dump(list(processados), f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"{Fore.RED}Erro ao salvar progresso no JSON: {e}{Style.RESET_ALL}")


def salvar_status_json(cpu, ram_pct, ram_usada, ram_total, concluidos, pendentes, total_arquivos, instancas_info, total_founds, finalizado=False):
    """Escreve o status.json atualizado em tempo real."""
    dados = {
        "timestamp": int(time.time()),
        "finalizado": finalizado,
        "sistema": {
            "cpu_percent": cpu,
            "ram_percent": ram_pct,
            "ram_usada_gb": round(ram_usada, 2),
            "ram_total_gb": round(ram_total, 2)
        },
        "progresso_geral": {
            "concluidos": concluidos,
            "pendentes": pendentes,
            "total_arquivos": total_arquivos,
            "total_founds": total_founds
        },
        "instancias": instancas_info
    }
    try:
        temp_file = f"{ARQUIVO_STATUS}.tmp"
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(dados, f, ensure_ascii=False, indent=2)
        os.replace(temp_file, ARQUIVO_STATUS)
    except Exception:
        pass


def contar_founds_locais(arquivo_saida="ggwp.txt"):
    """Conta total de linhas no arquivo de resultados local."""
    if os.path.exists(arquivo_saida):
        try:
            with open(arquivo_saida, 'r', encoding='utf-8', errors='ignore') as f:
                return sum(1 for line in f if line.strip())
        except Exception:
            return 0
    return 0


def criar_barra_progresso(porcentagem, tamanho=15):
    porcentagem = max(0.0, min(100.0, porcentagem))
    blocos = int((porcentagem / 100) * tamanho)
    vazio = tamanho - blocos
    cor = Fore.GREEN if porcentagem >= 99.0 else (Fore.YELLOW if porcentagem > 50.0 else Fore.CYAN)
    return f"[{cor}{'█' * blocos}{'░' * vazio}{Style.RESET_ALL}] {porcentagem:>5.1f}%"


def exibir_cabecalho(total_pendentes=0, total_arquivos=0):
    cpu_uso = psutil.cpu_percent(interval=None)
    ram = psutil.virtual_memory()
    ram_uso = ram.percent
    ram_usada_gb = ram.used / (1024 ** 3)
    ram_total_gb = ram.total / (1024 ** 3)

    cor_cpu = Fore.GREEN if cpu_uso < 70 else (Fore.YELLOW if cpu_uso < 85 else Fore.RED)
    cor_ram = Fore.GREEN if ram_uso < 70 else (Fore.YELLOW if ram_uso < 85 else Fore.RED)

    processados = carregar_progresso()
    qtd_concluidos = len(processados)

    print(f"{Fore.CYAN}╔══════════════════════════════════════════════════════════════════════╗{Style.RESET_ALL}")
    print(f"{Fore.CYAN}║                     GERENCIADOR LOCAL DE INSTÂNCIAS                  ║{Style.RESET_ALL}")
    print(f"{Fore.CYAN}╠══════════════════════════════════════════════════════════════════════╣{Style.RESET_ALL}")
    print(f"  CPU: {cor_cpu}{cpu_uso:>5.1f}%{Style.RESET_ALL}  │  RAM: {cor_ram}{ram_uso:>5.1f}%{Style.RESET_ALL} ({ram_usada_gb:.1f}/{ram_total_gb:.1f} GB)")
    
    if total_arquivos > 0:
        pct_geral = (qtd_concluidos / total_arquivos) * 100
        barra = criar_barra_progresso(pct_geral, tamanho=20)
        print(f"  Progresso Total: {barra} │ Concluídos: {Fore.GREEN}{qtd_concluidos}{Style.RESET_ALL}/{total_arquivos} │ Fila: {Fore.YELLOW}{total_pendentes}{Style.RESET_ALL}")
    else:
        print(f"  Histórico: {Fore.GREEN}{qtd_concluidos}{Style.RESET_ALL} arquivo(s) concluído(s)")
        
    print(f"{Fore.CYAN}╚══════════════════════════════════════════════════════════════════════╝{Style.RESET_ALL}")


def criar_sessao_tmux(arquivo_atual, arquivo_saida):
    timestamp_lote = int(time.time() * 1000)
    nome_sessao = f"{SESSION_PREFIX}{timestamp_lote}"
    comando_interno = f'python3 s.py -i "{arquivo_atual}" -o "{arquivo_saida}" || exec bash'

    cmd_tmux = [
        'tmux', 'new-session', '-d',
        '-s', nome_sessao,
        'bash', '-c', comando_interno
    ]

    try:
        subprocess.run(cmd_tmux, check=True)
        return nome_sessao
    except subprocess.CalledProcessError:
        return None


def processar_instancias_automatico(pasta=None, qtd_simultanea=None):
    if not pasta:
        limpar_tela()
        exibir_cabecalho()
        print(f"\n{Fore.GREEN}[ MODO AUTOMÁTICO CONTINUOUS ]{Style.RESET_ALL}\n")
        pasta = input(f"{Fore.CYAN}Caminho da pasta onde estão os arquivos .txt: {Style.RESET_ALL}").strip()

    pasta = pasta.strip('"').strip("'")

    if not os.path.isdir(pasta):
        print(f"\n{Fore.RED}Erro: O caminho informado '{pasta}' não é válido.{Style.RESET_ALL}")
        if qtd_simultanea is None:
            input(f"\n{Fore.CYAN}Pressione ENTER para voltar...{Style.RESET_ALL}")
        return

    processados = carregar_progresso()
    sessao_para_arquivo = {}

    arquivos_reservados = {'servidores.txt', 'downloads.txt', 'ggwp.txt'}
    todos_arquivos = []
    arquivos_pendentes = []

    for raiz, _, arquivos in os.walk(pasta):
        for f in sorted(arquivos):
            if f.lower().endswith('.txt') and f.lower() not in arquivos_reservados:
                caminho_completo = os.path.join(raiz, f)
                todos_arquivos.append(caminho_completo)
                if caminho_completo not in processados:
                    arquivos_pendentes.append(caminho_completo)

    total_arquivos_encontrados = len(todos_arquivos)

    if not arquivos_pendentes:
        limpar_tela()
        exibir_cabecalho(0, total_arquivos_encontrados)
        print(f"\n{Fore.GREEN}✔ Todos os {total_arquivos_encontrados} arquivos .txt já foram processados!{Style.RESET_ALL}")
        
        ram = psutil.virtual_memory()
        salvar_status_json(
            psutil.cpu_percent(), ram.percent, ram.used/(1024**3), ram.total/(1024**3),
            len(processados), 0, total_arquivos_encontrados, [], contar_founds_locais(), finalizado=True
        )
        if qtd_simultanea is None:
            input(f"\n{Fore.CYAN}Pressione ENTER para voltar...{Style.RESET_ALL}")
        return

    if qtd_simultanea is None:
        try:
            print(f"\n{Fore.GREEN}Total na pasta: {total_arquivos_encontrados} │ Concluídos: {len(processados)} │ Pendentes: {len(arquivos_pendentes)}{Style.RESET_ALL}")
            qtd_simultanea = int(input(f"{Fore.CYAN}Quantidade de instâncias SIMULTÂNEAS: {Style.RESET_ALL}"))
        except ValueError:
            print(f"\n{Fore.RED}Digite um número inteiro válido.{Style.RESET_ALL}")
            input(f"\n{Fore.CYAN}Pressione ENTER para voltar...{Style.RESET_ALL}")
            return

    if qtd_simultanea <= 0:
        print(f"\n{Fore.RED}A quantidade deve ser maior que zero.{Style.RESET_ALL}")
        if qtd_simultanea is None:
            input(f"\n{Fore.CYAN}Pressione ENTER para voltar...{Style.RESET_ALL}")
        return

    dir_raiz = os.path.dirname(os.path.abspath(__file__))
    arquivo_saida = os.path.join(dir_raiz, "ggwp.txt")

    print(f"\n{Fore.CYAN}Iniciando lote inicial de instâncias...{Style.RESET_ALL}\n")

    lote_inicial = min(qtd_simultanea, len(arquivos_pendentes))
    for _ in range(lote_inicial):
        arq = arquivos_pendentes.pop(0)
        sessao_criada = criar_sessao_tmux(arq, arquivo_saida)
        if sessao_criada:
            sessao_para_arquivo[sessao_criada] = arq
            print(f"  {Fore.GREEN}> Instância criada:{Style.RESET_ALL} {os.path.basename(arq)}")
        time.sleep(0.2)

    time.sleep(1.5)

    padrao_progresso = re.compile(
        r'progress\s+\d+/\d+\s+\(\s*(\d+(?:\.\d+)?)%\)\s*\|\s*found:\s*(\d+)\s*\|\s*errors:\s*(\d+)'
    )

    try:
        while True:
            limpar_tela()
            exibir_cabecalho(len(arquivos_pendentes), total_arquivos_encontrados)
            print(f"\n {Fore.GREEN}● MODO AUTOMÁTICO EM EXECUÇÃO{Style.RESET_ALL} {Fore.LIGHTBLACK_EX}(Ctrl+C para pausar){Style.RESET_ALL}")
            print(f" Fila Restante: {Fore.YELLOW}{len(arquivos_pendentes)}{Style.RESET_ALL} arquivos │ Saída: {Fore.YELLOW}ggwp.txt{Style.RESET_ALL}\n")

            resultado = subprocess.run(
                ['tmux', 'list-sessions'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            sessoes_ativas = []
            if resultado.returncode == 0:
                sessoes_ativas = [s.split(':')[0] for s in resultado.stdout.splitlines() if SESSION_PREFIX in s]

            if not sessoes_ativas and not arquivos_pendentes:
                limpar_tela()
                exibir_cabecalho(0, total_arquivos_encontrados)
                print(f"\n{Fore.GREEN}✔ TODOS OS ARQUIVOS FORAM PROCESSADOS COM SUCESSO!{Style.RESET_ALL}\n")
                
                ram = psutil.virtual_memory()
                salvar_status_json(
                    psutil.cpu_percent(), ram.percent, ram.used/(1024**3), ram.total/(1024**3),
                    len(processados), 0, total_arquivos_encontrados, [], contar_founds_locais(arquivo_saida), finalizado=True
                )
                break

            print(f"{Fore.CYAN}┌────┬──────────────────────────┬─────────────────────────────┬───────────┬──────────────┐{Style.RESET_ALL}")
            print(f"│ ID │ SESSÃO                   │ BARRA DE PROGRESSO          │ FOUNDS    │ STATUS       │")
            print(f"{Fore.CYAN}├────┼──────────────────────────┼─────────────────────────────┼───────────┼──────────────┤{Style.RESET_ALL}")

            sessoes_para_encerrar = []
            instancias_metria_json = []

            for idx, nome_sessao in enumerate(sessoes_ativas, start=1):
                captura = subprocess.run(
                    ['tmux', 'capture-pane', '-t', nome_sessao, '-p', '-S', '-50'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )

                linhas = captura.stdout.strip().splitlines()
                pct = None
                found = 0
                errors = 0
                foi_killed = False

                for linha in reversed(linhas):
                    if "Killed" in linha:
                        foi_killed = True

                    match = padrao_progresso.search(linha)
                    if match and pct is None:
                        pct = float(match.group(1))
                        found = int(match.group(2))
                        errors = int(match.group(3))

                if foi_killed:
                    status_txt = "KILLED"
                    cor_status = Fore.RED
                    sessoes_para_encerrar.append((nome_sessao, False))
                elif pct is not None and pct >= 99.0:
                    status_txt = "Concluído"
                    cor_status = Fore.GREEN
                    sessoes_para_encerrar.append((nome_sessao, True))
                else:
                    status_txt = "Rodando" if pct is not None else "Iniciando"
                    cor_status = Fore.CYAN

                pct_exibicao = pct if pct is not None else 0.0

                instancias_metria_json.append({
                    "sessao": nome_sessao,
                    "arquivo": os.path.basename(sessao_para_arquivo.get(nome_sessao, "")),
                    "progresso": pct_exibicao,
                    "founds": found,
                    "errors": errors,
                    "status": status_txt
                })

                barra_visual = criar_barra_progresso(pct_exibicao, tamanho=12)
                nome_exibicao = nome_sessao[-24:] if len(nome_sessao) > 24 else nome_sessao
                cor_found = Fore.GREEN if found > 0 else Fore.WHITE

                print(
                    f"│ {idx:>2} │ {nome_exibicao:<24} │ {barra_visual} │ {cor_found}{found:<9}{Style.RESET_ALL} │ {cor_status}{status_txt:<12}{Style.RESET_ALL} │"
                )

            print(f"{Fore.CYAN}└────┴──────────────────────────┴─────────────────────────────┴───────────┴──────────────┘{Style.RESET_ALL}")

            # Salva o status.json
            ram = psutil.virtual_memory()
            salvar_status_json(
                psutil.cpu_percent(),
                ram.percent,
                ram.used / (1024 ** 3),
                ram.total / (1024 ** 3),
                len(processados),
                len(arquivos_pendentes),
                total_arquivos_encontrados,
                instancias_metria_json,
                contar_founds_locais(arquivo_saida),
                finalizado=False
            )

            if sessoes_para_encerrar:
                print(f"\n{Fore.YELLOW}Encerrando instâncias e atualizando progresso.json...{Style.RESET_ALL}")
                for s_encerrar, sucesso in sessoes_para_encerrar:
                    subprocess.run(['tmux', 'kill-session', '-t', s_encerrar])
                    arq_associado = sessao_para_arquivo.pop(s_encerrar, None)

                    if sucesso and arq_associado:
                        processados.add(arq_associado)
                        salvar_progresso(processados)
                    elif not sucesso and arq_associado:
                        arquivos_pendentes.append(arq_associado)

                    if arquivos_pendentes:
                        proximo_arq = arquivos_pendentes.pop(0)
                        nova_sessao = criar_sessao_tmux(proximo_arq, arquivo_saida)
                        if nova_sessao:
                            sessao_para_arquivo[nova_sessao] = proximo_arq

            time.sleep(5)

    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}Monitoramento pausado.{Style.RESET_ALL}")


def main():
    parser = argparse.ArgumentParser(description="Gerenciador de Instâncias")
    parser.add_argument("--auto", action="store_true", help="Executa no modo automático via linha de comando")
    parser.add_argument("-p", "--folder", type=str, help="Caminho da pasta contendo os arquivos .txt")
    parser.add_argument("-i", "--instances", type=int, help="Quantidade de instâncias simultâneas")

    args = parser.parse_args()

    if args.auto:
        if not args.folder or not args.instances:
            print(f"{Fore.RED}Erro: Para o modo --auto, forneça -p <pasta> e -i <instancias>{Style.RESET_ALL}")
            return
        processar_instancias_automatico(pasta=args.folder, qtd_simultanea=args.instances)
        return

    while True:
        limpar_tela()
        exibir_cabecalho()
        print(f"\n {Fore.CYAN}OPÇÕES DISPONÍVEIS:{Style.RESET_ALL}")
        print(f"   [1] Iniciar instâncias (Modo Automático Continuous)")
        print(f"   [0] Sair\n")

        escolha = input(f"{Fore.CYAN}Escolha uma opção: {Style.RESET_ALL}").strip()

        if escolha == '0':
            break
        elif escolha == '1':
            processar_instancias_automatico()


if __name__ == '__main__':
    main()